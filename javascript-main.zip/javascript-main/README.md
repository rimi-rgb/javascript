# javascript
this is my javascript practice folder
